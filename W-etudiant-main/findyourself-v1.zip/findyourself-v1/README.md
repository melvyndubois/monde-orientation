# FindYourself — v1 Test Pilote

Outil d'orientation professionnelle pour les jeunes (15-25 ans) qui analyse leurs données comportementales exportées depuis TikTok ou Instagram pour générer un rapport d'orientation personnalisé via IA.

---

## Lancer le projet

Ouvrir `index.html` dans un navigateur. **Aucune installation requise.**

> Pour le mode démo ou les fonctionnalités d'import de fichier local, certains navigateurs bloquent les requêtes `fetch` sur `file://`. Si la démo ne charge pas le fichier automatiquement, les données inline de secours prennent le relais.
>
> Pour éviter ce problème, lance un mini-serveur local :
> ```bash
> # Python 3
> python -m http.server 8080
> # puis ouvre http://localhost:8080
> ```

---

## Utiliser la démo

1. Cliquer **"Voir la démo"** sur l'écran d'accueil
2. Le formulaire se pré-remplit automatiquement avec le profil de Tony (16 ans, 2nde)
3. Les données de `demo-data/tony_demo.json` sont chargées
4. Saisir une clé API Anthropic et cliquer **"Analyser mon profil →"**

---

## Utiliser avec de vraies données

### TikTok
1. Aller dans **Profil → ⋮ → Confidentialité → Télécharger tes données**
2. Sélectionner le format **JSON** (pas TXT)
3. Délai d'export : environ 3 à 7 jours
4. Déposer le fichier `user_data.json` dans l'app

### Instagram
1. Aller dans **Paramètres → Tes activités → Télécharger tes informations**
2. Sélectionner le format **JSON**
3. Déposer le `.zip` ou le fichier `your_topics.json` extrait dans l'app

---

## Clé API Anthropic

L'app appelle l'API Anthropic directement depuis le navigateur.

- Obtenir une clé : https://console.anthropic.com
- La clé commence par `sk-ant-api03-…`
- Pour le pilote interne, tu peux pré-remplir la constante `PREFILLED_KEY` dans `index.html` (ligne ~430 du JS)

> ⚠️ **En production**, cette clé doit être sécurisée via un proxy backend. Pour le pilote (usage interne uniquement), la clé peut être embarquée dans le code.

### Modèle utilisé

La constante `CLAUDE_MODEL` (en haut du JS dans `index.html`) définit le modèle. Par défaut : `claude-opus-4-5`. Consulte [la liste des modèles disponibles](https://docs.anthropic.com/en/docs/about-claude/models) pour utiliser la dernière version.

---

## Architecture

```
findyourself-v1/
├── index.html              ← App complète auto-contenue (HTML/CSS/JS vanilla)
├── demo-data/
│   └── tony_demo.json      ← Données de démo simulées (export TikTok)
└── README.md
```

**Pas de framework, pas de build, pas de backend.** Déploiement sur Netlify ou GitHub Pages en glisser-déposer.

---

## Déploiement

### Netlify (recommandé)
1. Aller sur https://app.netlify.com
2. "Add new site → Deploy manually"
3. Glisser le dossier `findyourself-v1/` dans la zone de dépôt
4. L'URL est disponible instantanément

### GitHub Pages
1. Créer un repo, pousser le dossier
2. Settings → Pages → Source : `main` / `root`

---

## Confidentialité

- **Aucune donnée envoyée à un serveur FindYourself**
- Les données transitent uniquement vers l'API Anthropic pour l'analyse
- Aucune donnée n'est conservée après la session (pas de cookies, pas de localStorage)
- Ce point doit être expliqué aux jeunes et aux conseillers avant utilisation

---

## Contact & pilote

**Clément Gal** — clement.gal.pro@gmail.com

Pour toute question sur le pilote, les partenariats Missions Locales / lycées, ou l'évolution vers une v2 avec backend sécurisé.
